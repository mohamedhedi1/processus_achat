package com.example.processus_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessusBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
