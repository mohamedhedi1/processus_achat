package com.example.processus_backend.user;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;

import java.util.List;

public class UserConfig {
    /*
    @Bean
    CommandLineRunner commandLineRunner(UserRepository userRepository)
    {
        return args ->
        {
            User mariem= new User(
           "email1",
            "firstName1",
            "lastName1",
            "post1",
            "cin1"
            );
            User alex=new User(
                    "email12",
                    "firstName12",
                    "lastName12",
                    "post12",
                    "cin12"
            );
            userRepository.saveAll(List.of(mariem,alex));
        };


    }*/
}
