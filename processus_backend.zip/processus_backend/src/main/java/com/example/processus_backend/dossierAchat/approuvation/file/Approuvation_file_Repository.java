package com.example.processus_backend.dossierAchat.approuvation.file;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface Approuvation_file_Repository extends JpaRepository<Approuvation_file,Long> {

}
