package com.example.processus_backend.dossierAchat.approuvation.dossier;

import com.example.processus_backend.dossierAchat.DemandeAchat;
import com.example.processus_backend.dossierAchat.DemandeAchatRepository;
import com.example.processus_backend.dossierAchat.etape.Etape;
import com.example.processus_backend.dossierAchat.etape.EtapeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ApprouvationDossierService {
    private  final DemandeAchatRepository demandeAchatRepository;
    private final EtapeRepository etapeRepository;
    private final ApprouvationDoosierRepository approuvationDoosierRepository;
    @Autowired
    public ApprouvationDossierService(DemandeAchatRepository demandeAchatRepository, EtapeRepository etapeRepository, ApprouvationDoosierRepository approuvationDoosierRepository) {
        this.demandeAchatRepository = demandeAchatRepository;
        this.etapeRepository = etapeRepository;
        this.approuvationDoosierRepository = approuvationDoosierRepository;
    }

    public void add(Approuvation_dossier_Request approuvation_dossier_request){
        DemandeAchat demandeAchat=demandeAchatRepository.findById(approuvation_dossier_request.getDemandeAchat()).orElse(null);
        Etape etape = etapeRepository.getById(approuvation_dossier_request.getEtape());
        Approuvation_dossier approuvation_dossier= Approuvation_dossier.builder()
                .approuvation(approuvation_dossier_request.getApprouvation())
                .demandeAchat(demandeAchat)
                .remarque(approuvation_dossier_request.getRemarque())
                .etape(etape)
                .build();
        approuvationDoosierRepository.save(approuvation_dossier);
    }

    public List<DemandeAchat> get_by_etape(Long etape) {

        List<Approuvation_dossier> approuvation_dossiers =approuvationDoosierRepository.getApprouvationDossierbyETAPE(etape);
        List<DemandeAchat> demandeAchats =new ArrayList<DemandeAchat>();

        for(int i=0 ;i<approuvation_dossiers.size();i++){
             String traitement=approuvation_dossiers.get(i).getApprouvation();
             if(traitement.equals("notraite")) {
                 demandeAchats.add(approuvation_dossiers.get(i).getDemandeAchat());
             }

        }

        return  demandeAchats ;
    }
}
